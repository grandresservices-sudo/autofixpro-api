const express = require('express');
const Invoice = require('../models/Invoice');
const { auth, ownerOnly } = require('../middleware/auth');
const router = express.Router();

// Create (owner)
router.post('/', auth, ownerOnly, async (req, res) => {
  try {
    const inv = new Invoice(req.body);
    await inv.save();
    await inv.populate('customer', 'name email');
    res.status(201).json(inv);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// All invoices (owner)
router.get('/all', auth, ownerOnly, async (req, res) => {
  try {
    const invs = await Invoice.find().sort({ createdAt: -1 }).populate('customer', 'name email phone');
    res.json(invs);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// My invoices (customer)
router.get('/my', auth, async (req, res) => {
  try {
    const invs = await Invoice.find({ customer: req.user._id }).sort({ createdAt: -1 });
    res.json(invs);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Update invoice (owner)
router.put('/:id', auth, ownerOnly, async (req, res) => {
  try {
    const inv = await Invoice.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: false }).populate('customer', 'name email');
    if (!inv) return res.status(404).json({ error: 'Not found' });
    res.json(inv);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Pay invoice (customer or owner)
router.put('/:id/pay', auth, async (req, res) => {
  try {
    const inv = await Invoice.findByIdAndUpdate(
      req.params.id,
      { status: 'paid', paidAt: new Date(), paymentMethod: req.body.method || 'online' },
      { new: true }
    );
    if (!inv) return res.status(404).json({ error: 'Not found' });
    res.json(inv);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Revenue stats (owner)
router.get('/stats', auth, ownerOnly, async (req, res) => {
  try {
    const monthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
    const lastMonthStart = new Date(new Date().getFullYear(), new Date().getMonth() - 1, 1);
    const lastMonthEnd = new Date(new Date().getFullYear(), new Date().getMonth(), 0);

    const [allPaid, monthPaid, lastMonthPaid, totalInvoices, pendingInvoices] = await Promise.all([
      Invoice.aggregate([{ $match: { status: 'paid' } }, { $group: { _id: null, total: { $sum: '$total' } } }]),
      Invoice.aggregate([{ $match: { status: 'paid', paidAt: { $gte: monthStart } } }, { $group: { _id: null, total: { $sum: '$total' } } }]),
      Invoice.aggregate([{ $match: { status: 'paid', paidAt: { $gte: lastMonthStart, $lte: lastMonthEnd } } }, { $group: { _id: null, total: { $sum: '$total' } } }]),
      Invoice.countDocuments(),
      Invoice.countDocuments({ status: { $in: ['sent', 'overdue'] } })
    ]);

    // Monthly revenue for chart (last 6 months)
    const monthlyRevenue = await Invoice.aggregate([
      { $match: { status: 'paid', paidAt: { $gte: new Date(new Date().setMonth(new Date().getMonth() - 6)) } } },
      { $group: { _id: { year: { $year: '$paidAt' }, month: { $month: '$paidAt' } }, revenue: { $sum: '$total' }, count: { $sum: 1 } } },
      { $sort: { '_id.year': 1, '_id.month': 1 } }
    ]);

    res.json({
      totalRevenue: allPaid[0]?.total || 0,
      monthRevenue: monthPaid[0]?.total || 0,
      lastMonthRevenue: lastMonthPaid[0]?.total || 0,
      totalInvoices,
      pendingInvoices,
      monthlyRevenue
    });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
