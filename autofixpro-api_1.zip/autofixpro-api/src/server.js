require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
const server = http.createServer(app);

const allowedOrigins = [
  process.env.FRONTEND_URL || 'http://localhost:3000',
  'http://localhost:3000',
  'https://localhost:3000'
];

const io = new Server(server, {
  cors: { origin: '*', methods: ['GET', 'POST'] }
});

app.use(cors({ origin: '*' }));
app.use(express.json());

// Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/appointments', require('./routes/appointments'));
app.use('/api/vehicles', require('./routes/vehicles'));
app.use('/api/invoices', require('./routes/invoices'));
app.use('/api/messages', require('./routes/messages'));
app.use('/api/payments', require('./routes/payments'));

app.get('/api/health', (req, res) => res.json({ status: 'ok', service: 'AutoFix Pro API v2' }));

// ─── REAL-TIME SOCKET.IO ──────────────────────────────────────────────────────
io.on('connection', (socket) => {
  socket.on('join_room', ({ roomId, userId, userName }) => {
    socket.join(roomId);
    socket.data.userId = userId;
    socket.data.userName = userName;
    socket.data.roomId = roomId;
  });

  socket.on('send_message', async (data) => {
    // Broadcast to room
    io.to(data.roomId).emit('receive_message', {
      ...data,
      timestamp: new Date().toISOString()
    });
  });

  socket.on('typing', ({ roomId, userName }) => {
    socket.to(roomId).emit('user_typing', { userName });
  });

  socket.on('stop_typing', ({ roomId }) => {
    socket.to(roomId).emit('user_stop_typing');
  });

  // Appointment status update notification
  socket.on('status_update', (data) => {
    io.to(`customer_${data.customerId}`).emit('appointment_updated', data);
  });
});

// Make io available to routes
app.set('io', io);

// MongoDB
mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/autofixpro')
  .then(() => console.log('✅ MongoDB connected'))
  .catch(err => console.error('MongoDB error:', err));

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => console.log(`🚀 AutoFix Pro API running on port ${PORT}`));
